export const socialProofMessages = [
  {
    name: "Ayesha",
    action: "just enrolled in the workshop",
    location: "Lahore",
  },
  {
    name: "Daniel",
    action: "reserved a seat for his team",
    location: "Nairobi",
  },
  {
    name: "Maya",
    action: "grabbed the early-bird offer",
    location: "London",
  },
  {
    name: "Ravi",
    action: "signed up after the free preview",
    location: "Bengaluru",
  },
  {
    name: "Sofia",
    action: "joined to launch her digital product",
    location: "Lisbon",
  },
];
