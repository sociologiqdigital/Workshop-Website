export const details = [
  { icon: "Calendar", label: "Duration", value: "4 Weeks" },
  { icon: "Clock", label: "Time Commitment", value: "2 hours/week" },
  { icon: "MapPin", label: "Format", value: "Live Online" },
  { icon: "Users", label: "Group Size", value: "Limited to 20" },
];
