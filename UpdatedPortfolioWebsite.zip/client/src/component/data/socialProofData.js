export const socialProofMessages = [
  {
    name: "Anjali",
    action: "just enrolled for the live sessions",
    location: "Chennai",
    // avatar: "/images/avatars/avatar-1.jpg",
  },
  {
    name: "Sneha",
    action: "booked a 1:1 clarity call",
    location: "Pune",
    // avatar: "/images/avatars/avatar-2.jpg",
  },
  {
    name: "Ritika",
    action: "joined the 4-week workshop",
    location: "Delhi",
    // avatar: "/images/avatars/avatar-3.jpg",
  },
];
