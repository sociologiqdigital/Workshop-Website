import React from 'react'

const SectionHeader = () => {
  return (
    <div>SectionHeader</div>
  )
}

export default SectionHeader